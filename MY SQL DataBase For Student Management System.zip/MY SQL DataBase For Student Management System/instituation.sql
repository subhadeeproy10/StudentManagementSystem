﻿# Host: localhost  (Version 5.5.54-log)
# Date: 2019-01-18 16:57:40
# Generator: MySQL-Front 6.0  (Build 2.20)


#
# Structure for table "admin"
#

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` varchar(20) NOT NULL,
  `admin_password` varchar(20) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "admin"
#

INSERT INTO `admin` VALUES ('admin','nimda');

#
# Structure for table "class_info"
#

DROP TABLE IF EXISTS `class_info`;
CREATE TABLE `class_info` (
  `Subject_Code` varchar(255) NOT NULL,
  `Subject_Name` varchar(255) NOT NULL,
  `Employee_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`Subject_Code`,`Employee_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "class_info"
#

INSERT INTO `class_info` VALUES ('1111','y678','jjj'),('1234','ff','kk'),('1234444','fdfbdf','dbdbdfg'),('12345','dbms','11111'),('12345','gthy','ccc'),('12345','mca401','cpp'),('200','MCA101','C'),('2000','bca401','C'),('632873','mca501','java'),('960','lkjl','lk'),('ggjjg','gg','gg'),('mca401','cpp','632873'),('MCA404','dbms','123'),('mca501','vb','s123'),('mca801','network','123456'),('qq','qq','qq'),('qqqq','qqqq','qqq');

#
# Structure for table "internal_marks"
#

DROP TABLE IF EXISTS `internal_marks`;
CREATE TABLE `internal_marks` (
  `Student_ID` varchar(255) NOT NULL,
  `Subject_Code` varchar(255) NOT NULL,
  `Marks` varchar(255) NOT NULL,
  `Employee_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`Student_ID`,`Subject_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "internal_marks"
#

INSERT INTO `internal_marks` VALUES ('111','12345','80','11111'),('1234','mca501','50','s123'),('fff','1111','46','jjj'),('fff','mca801','101','123456'),('kkk','1111','12233','jjj');

#
# Structure for table "semester_marks"
#

DROP TABLE IF EXISTS `semester_marks`;
CREATE TABLE `semester_marks` (
  `Student_ID` varchar(255) NOT NULL,
  `Subject_Code` varchar(255) NOT NULL,
  `Marks` varchar(255) NOT NULL,
  `Employee_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`Student_ID`,`Subject_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "semester_marks"
#

INSERT INTO `semester_marks` VALUES ('111111','mca801','100','123456'),('632873','mca401','600','632873'),('7890','scf56','40','1234'),('88','kk','80','66'),('888','kk','80','8888'),('dd','632873','100','java'),('deep','1234','999999','kk'),('jjj','1111','45','jjj'),('kkk','1111','56','jjj'),('rr','qq','456','qq'),('uuu','1111','45','jjj');

#
# Structure for table "student_attendance"
#

DROP TABLE IF EXISTS `student_attendance`;
CREATE TABLE `student_attendance` (
  `Subject_Code` varchar(255) NOT NULL,
  `Date_Attend` varchar(255) NOT NULL,
  `Attendance` varchar(255) NOT NULL,
  `Student_ID` varchar(255) NOT NULL,
  `Employee_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`Subject_Code`,`Date_Attend`,`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "student_attendance"
#

INSERT INTO `student_attendance` VALUES ('1111','2018-11-25','2','hhh','jjj'),('632873','2018-11-24','2','deep','java'),('mca501','2018-11-24','2','1234','s123');

#
# Structure for table "student_info"
#

DROP TABLE IF EXISTS `student_info`;
CREATE TABLE `student_info` (
  `First_Name` varchar(255) NOT NULL,
  `Middle_Name` varchar(255) DEFAULT NULL,
  `Last_Name` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Student_ID` varchar(255) NOT NULL,
  `Roll_No` varchar(255) NOT NULL,
  `Dept_Name` varchar(255) NOT NULL,
  `DOB` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Contact_No` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `Pin` varchar(255) NOT NULL,
  `YOP` varchar(255) NOT NULL,
  PRIMARY KEY (`Student_ID`,`UserName`,`Password`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "student_info"
#

INSERT INTO `student_info` VALUES ('Debdutta','','Chatterjee','Debdutta','1505','102365','30701016042','MCA','1994-05-15','subhadeeproy816@gmail.com','8974556','Female','162,S.C CHATTERJEE STREET,KONNAGAR','HOOGHLY','WB','INDIA','712235','2019'),('deepppppp','','royyy','deep123','deep123','1237','1237','mca','1994-09-10','subhadeeproy816@gmail.com','9531782444','Male','ffffff','fff','fff','fff','713149','2019'),('Subhadeep','','Roy','Subhadeepsr','sdsdsd','14536','30701016003','MCA','1994-09-10','subhadeeproy816@gmail.com','9775740718','Male','Barddhaman','Barddhaman','wb','ind','713149','2019'),('deep','','roy','deeproysr','deep420roy','632873','123456789','mca','1995-09-10','subhadeeproy@hotmail.com','7586986013','Male','abc','bur','wb','nd','713101','2019');

#
# Structure for table "teacher_info"
#

DROP TABLE IF EXISTS `teacher_info`;
CREATE TABLE `teacher_info` (
  `First_Name` varchar(200) DEFAULT NULL,
  `Middle_Name` varchar(200) DEFAULT NULL,
  `Last_Name` varchar(45) DEFAULT NULL,
  `DOB` varchar(20) DEFAULT NULL,
  `Employee_ID` varchar(20) NOT NULL DEFAULT '',
  `Designation` varchar(20) DEFAULT NULL,
  `Department` varchar(40) DEFAULT NULL,
  `DOJ` varchar(20) DEFAULT NULL,
  `House_No` varchar(200) DEFAULT NULL,
  `Street_Name` varchar(200) DEFAULT NULL,
  `P.O.` varchar(100) DEFAULT NULL,
  `District` varchar(200) DEFAULT NULL,
  `Pin` varchar(10) DEFAULT NULL,
  `State` varchar(100) DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `Sex` varchar(10) DEFAULT NULL,
  `Phone_No` varchar(10) DEFAULT NULL,
  `Alternate_Phone_NO` varchar(10) DEFAULT NULL,
  `Email_ID` varchar(300) DEFAULT NULL,
  `Alternate_Email_ID` varchar(300) DEFAULT NULL,
  `User_Name` varchar(128) DEFAULT NULL,
  `Password` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`Employee_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "teacher_info"
#

INSERT INTO `teacher_info` VALUES ('Sandip','','Ghosal','1983-10-10','122','ASSPROF','MCA','2009-11-11','12','DXHFH','gg','Kolkata','222','WB','INDIA','Male','789456123','369852147','sg@gmail.com',NULL,'SG22','SG22'),('Sandeep','','Ghosal','2018-11-07','12343','professor','MCA','2018-11-14','145897','FFF','FFF','FFF','6666','WB','IND','Male','566656636','56663232','',NULL,'',''),('sourav','','MAJUMDER','1990-09-10','12345','PROFESSOR','mca','2018-11-14','1234','gg','gg','gg','6666','wb','ind','Male','6446666','9964666','subhadeep@hotmail.com',NULL,'s123','s123'),('SUBHADEEP','ttt','ROY','opu','123456678911','ggg','ddddd','dddd','ffff','ffff','hhh','ggg','','','','','','','','','','ggg'),('SUBHADEEP','','ROY','','12345678','ggg','ddddd','User_Name','','','','','','','','','','','','','',''),('Pradosh','','Bandopadhyay','1982-10-11','1235','PROFESSOR','MCA','2009-11-10','12','FDGF','DFD','FHG','12456','DGFD','FGF','Male','0123564555','','subhadeep@hotmail.com',NULL,'1111','1111'),('SUBHADEEP','ttt','ROY','opu','12366911','ggg','ddddd','dddd','ffff','ffff','hhh','ggg','iopuyr','oiuyt','njklo','uiopuy','hyui','yuio','','','','ggg'),('Prem','','Basu','1995-01-18','632873','tester','it','2017-04-25','123','abc','dfg','bur','713424','wb','ind','Male','9775081003','7001242007','prem.basu102@gmail.com',NULL,'prem420basu','prem420basu'),('SDEEP','ttt','ROY','opu','8865911','ggg','ddddd','dddd','ffff','ffff','hhh','ggg','iopuyr','oiuyt','njklo','uiopuy','hyui','yuio','tt','hh','hh','ggg');
